# HUDSON OS (Stages 1 to 3)

Your phone. Your orbit. Your rules.

- Stage 1: home app registration, clock, date, safe areas.
- Stage 2: installed-app discovery and launching (LauncherApps API).
- Stage 3: the Infinite Ring. Drag or flick to rotate (both directions, with momentum),
  slow idle drift, tap to launch, long-press to move or remove. In the app list
  (swipe up), long-press an app to add it. Shortcuts are saved locally with DataStore.
  Light haptic ticks while spinning; system reduced-motion is respected.

Not yet: ring size/speed/sound/haptic settings and themes (5), drawer search and list layout (4),
notifications and media (6), in-app French switch (7).

Status: written but not compiled by the author. Paste any build error back to fix it.
