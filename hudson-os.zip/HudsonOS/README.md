# HUDSON OS (Stages 1 and 2)

Your phone. Your orbit. Your rules.

- Stage 1: registers as a home app, clock, date, ring outline, safe areas.
- Stage 2: discovers installed apps (LauncherApps API) and launches them.
  Swipe up on the home screen to open the app list; Back or Home closes it.
  Unlaunchable apps show a message instead of crashing.

Not yet implemented: interactive ring (3), drawer search/layouts (4), themes,
icon styles, wallpaper, settings (5), notifications and media (6), in-app French switch (7).

## Build without a computer
See the GitHub Actions workflow file build-apk.yml that came with this zip.
Status: written but not compiled yet. Paste any build error back to fix it.
