# HUDSON OS

Your phone. Your orbit. Your rules.

Implemented (written, NOT yet compiled or tested on a device by the author):
- Home app registration, clock/date (24h, 12h or system), safe areas and cutouts.
- Installed-app discovery and launching through the LauncherApps API.
- Infinite Ring: drag/flick, momentum, idle drift, tap to launch, long-press to move/remove,
  centre hub for the selected app, haptic ticks, optional click sound, reduced motion.
- App list (swipe up): search (accent-insensitive), grid or list, launch, add to ring.
- Themes: Void, Ghost, Ice, Neon, Paper. Icon styles: Outline, Monochrome, Original.
- Wallpaper from the system photo picker with dimming.
- Settings screen (all values saved with DataStore). English and French, switchable in-app.
- Notification indicators (counts per app only) and a media banner, both through one
  notification-listener permission that the user grants in system settings.

Not implemented: notification previews, "always show" media banner option, outline icons on
Android 12 and older (letters are shown instead; use Monochrome or Original there).

Build: see build-apk.yml (GitHub Actions) or open the folder in Android Studio.
