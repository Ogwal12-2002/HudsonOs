package com.hudson.os.ui.apps

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.hudson.os.R
import com.hudson.os.data.apps.AppEntry
import com.hudson.os.ui.theme.Hudson

/** Long-press actions, shared by the ring and the app list. */
@Composable
fun AppActionsDialog(
    app: AppEntry,
    inRing: Boolean,
    onDismiss: () -> Unit,
    onOpen: () -> Unit,
    onAdd: () -> Unit,
    onRemove: () -> Unit,
    onMoveBack: () -> Unit,
    onMoveForward: () -> Unit,
) {
    val c = Hudson.colors
    fun act(block: () -> Unit): () -> Unit = {
        onDismiss()
        block()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        containerColor = c.background,
        shape = RoundedCornerShape(24.dp),
        title = { Text(app.label, color = c.foreground, fontWeight = FontWeight.Light) },
        text = {
            Column {
                ActionRow(R.string.action_open, act(onOpen))
                if (inRing) {
                    ActionRow(R.string.action_move_back, act(onMoveBack))
                    ActionRow(R.string.action_move_forward, act(onMoveForward))
                    ActionRow(R.string.action_remove_ring, act(onRemove))
                } else {
                    ActionRow(R.string.action_add_ring, act(onAdd))
                }
            }
        },
    )
}

@Composable
private fun ActionRow(@StringRes label: Int, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Text(
            text = stringResource(label),
            color = Hudson.colors.foreground,
            textAlign = TextAlign.Start,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}
