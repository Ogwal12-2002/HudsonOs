package com.hudson.os.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.io.IOException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.hudsonDataStore: DataStore<Preferences> by preferencesDataStore(name = "hudson_prefs")

/** Ring shortcuts, stored locally as component names. Nothing leaves the device. */
class FavoritesStore(context: Context) {
    private val store = context.applicationContext.hudsonDataStore

    /** Emits null while the user has never edited the ring (defaults then apply). */
    val favorites: Flow<List<String>?> = store.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { prefs -> prefs[KEY]?.split('\n')?.filter { it.isNotEmpty() } }

    suspend fun save(keys: List<String>) {
        store.edit { it[KEY] = keys.joinToString("\n") }
    }

    private companion object {
        val KEY = stringPreferencesKey("ring_favorites")
    }
}
