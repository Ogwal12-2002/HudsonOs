package com.hudson.os.media

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.hudson.os.notifications.HudsonNotificationListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

data class MediaUi(
    val title: String,
    val artist: String,
    val art: ImageBitmap?,
    val isPlaying: Boolean,
    val positionMs: Long,
    val durationMs: Long,
    val updateTime: Long,
    val speed: Float,
    val canPlayPause: Boolean,
    val canNext: Boolean,
    val canPrevious: Boolean,
)

/**
 * Reads the active media session. Android only allows this for an enabled notification listener,
 * so without notification access it quietly reports nothing.
 */
class MediaSessionRepository(context: Context) {
    private val appContext = context.applicationContext
    private val manager = appContext.getSystemService(MediaSessionManager::class.java)
    private val listenerComponent = ComponentName(appContext, HudsonNotificationListener::class.java)

    @Volatile
    private var controller: MediaController? = null

    fun observe(): Flow<MediaUi?> = callbackFlow {
        val callback = object : MediaController.Callback() {
            override fun onMetadataChanged(metadata: MediaMetadata?) {
                trySend(snapshot())
            }

            override fun onPlaybackStateChanged(state: PlaybackState?) {
                trySend(snapshot())
            }

            override fun onSessionDestroyed() {
                trySend(null)
            }
        }

        fun bind(list: List<MediaController>?) {
            controller?.unregisterCallback(callback)
            controller = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
                ?: list?.firstOrNull()
            controller?.registerCallback(callback)
            trySend(snapshot())
        }

        val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { bind(it) }
        try {
            manager.addOnActiveSessionsChangedListener(sessionsListener, listenerComponent)
            bind(manager.getActiveSessions(listenerComponent))
        } catch (e: SecurityException) {
            trySend(null)
        }
        awaitClose {
            runCatching { manager.removeOnActiveSessionsChangedListener(sessionsListener) }
            controller?.unregisterCallback(callback)
            controller = null
        }
    }

    private fun snapshot(): MediaUi? {
        val c = controller ?: return null
        val meta = c.metadata ?: return null
        val state = c.playbackState
        val title = meta.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
        if (title.isNullOrBlank()) return null
        val artist = meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
            ?: ""
        val art = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val actions = state?.actions ?: 0L
        val playPauseMask = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE
        return MediaUi(
            title = title,
            artist = artist,
            art = art?.asImageBitmap(),
            isPlaying = state?.state == PlaybackState.STATE_PLAYING,
            positionMs = state?.position ?: 0L,
            durationMs = meta.getLong(MediaMetadata.METADATA_KEY_DURATION),
            updateTime = state?.lastPositionUpdateTime ?: 0L,
            speed = state?.playbackSpeed ?: 1f,
            canPlayPause = actions and playPauseMask != 0L,
            canNext = actions and PlaybackState.ACTION_SKIP_TO_NEXT != 0L,
            canPrevious = actions and PlaybackState.ACTION_SKIP_TO_PREVIOUS != 0L,
        )
    }

    fun playPause() {
        val c = controller ?: return
        runCatching {
            if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
            else c.transportControls.play()
        }
    }

    fun next() {
        runCatching { controller?.transportControls?.skipToNext() }
    }

    fun previous() {
        runCatching { controller?.transportControls?.skipToPrevious() }
    }
}
