package com.hudson.os.settings

import android.app.Application
import android.net.Uri
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hudson.os.data.LauncherSettings
import java.io.File
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = SettingsRepository(application)

    /** null until the first read finishes, so the UI never flashes default settings. */
    val settings: StateFlow<LauncherSettings?> = repository.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    fun <T> set(key: Preferences.Key<T>, value: T) {
        viewModelScope.launch { repository.set(key, value) }
    }

    fun saveFavorites(keys: List<String>) {
        viewModelScope.launch { repository.saveFavorites(keys) }
    }

    fun resetRing() {
        viewModelScope.launch { repository.resetRing() }
    }

    fun importWallpaper(uri: Uri, onResult: (Boolean) -> Unit) {
        viewModelScope.launch { onResult(repository.importWallpaper(uri)) }
    }

    fun clearWallpaper() {
        viewModelScope.launch { repository.clearWallpaper() }
    }

    fun wallpaperFile(): File = repository.wallpaperFile()
}
