package com.hudson.os.ui.ring

import android.content.Context
import android.provider.Settings
import androidx.compose.runtime.Immutable

/** Defaults for now; the Settings screen (Stage 5) will drive these values. */
@Immutable
data class RingConfig(
    val sizeScale: Float = 1f,
    val driftDegPerSec: Float = 7f,
    val haptics: Boolean = true,
    val reducedMotion: Boolean = false,
)

/** True when the user turned system animations off. */
fun systemReducedMotion(context: Context): Boolean =
    Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
