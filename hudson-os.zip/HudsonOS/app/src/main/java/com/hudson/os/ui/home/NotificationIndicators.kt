package com.hudson.os.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hudson.os.R
import com.hudson.os.data.IconStyle
import com.hudson.os.data.apps.AppEntry
import com.hudson.os.ui.apps.AppIconImage
import com.hudson.os.ui.apps.AppsViewModel
import com.hudson.os.ui.theme.GlyphButton
import com.hudson.os.ui.theme.GlyphKind
import com.hudson.os.ui.theme.Hudson

/**
 * One small icon per app that has notifications, with a count. Content is never shown.
 * Without notification access, a single bell explains and requests it.
 */
@Composable
fun NotificationIndicators(
    accessGranted: Boolean,
    items: List<Pair<AppEntry, Int>>,
    vm: AppsViewModel,
    iconStyle: IconStyle,
    onOpen: (AppEntry) -> Unit,
    onRequestAccess: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = Hudson.colors
    Row(
        modifier.heightIn(min = 46.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (!accessGranted) {
            GlyphButton(GlyphKind.Bell, stringResource(R.string.cd_enable_notifications), onRequestAccess, size = 38.dp)
        } else {
            items.forEach { (app, n) ->
                Box(Modifier.size(46.dp).clickable { onOpen(app) }) {
                    AppIconImage(vm, app, iconStyle, 34.dp, Modifier.align(Alignment.Center))
                    Box(
                        Modifier
                            .align(Alignment.TopEnd)
                            .size(18.dp)
                            .background(c.foreground.copy(alpha = 0.22f), CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(if (n > 99) "99" else n.toString(), color = c.foreground, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

/** Plain-language explanation shown before sending the user to system settings. */
@Composable
fun NotificationAccessDialog(onDismiss: () -> Unit, onOpenSettings: () -> Unit) {
    val c = Hudson.colors
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.background,
        shape = RoundedCornerShape(24.dp),
        title = {
            Text(stringResource(R.string.notif_access_title), color = c.foreground, fontWeight = FontWeight.Light)
        },
        text = { Text(stringResource(R.string.notif_access_why), color = c.dim) },
        confirmButton = {
            TextButton(onClick = onOpenSettings) {
                Text(stringResource(R.string.notif_access_open), color = c.foreground)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.not_now), color = c.dim)
            }
        },
    )
}
