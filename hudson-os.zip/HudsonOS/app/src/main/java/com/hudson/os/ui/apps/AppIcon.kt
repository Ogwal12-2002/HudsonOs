package com.hudson.os.ui.apps

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import com.hudson.os.data.IconStyle
import com.hudson.os.data.apps.AppEntry
import com.hudson.os.data.apps.AppIcon
import com.hudson.os.ui.theme.Hudson

private class IconResult(val icon: AppIcon?)

/**
 * One app icon in the chosen style. Outline uses the app's themed monochrome glyph when it has one
 * (Android 13+); otherwise it shows the app's first letter, the same fallback for every such app.
 */
@Composable
fun AppIconImage(vm: AppsViewModel, app: AppEntry, style: IconStyle, size: Dp, modifier: Modifier = Modifier) {
    val c = Hudson.colors
    val full = style == IconStyle.ORIGINAL
    val glyphSize = if (full) size else size * 0.62f
    val px = with(LocalDensity.current) { glyphSize.roundToPx() }
    val result by produceState<IconResult?>(null, app.key, px, style) {
        value = IconResult(vm.icon(app, px, style))
    }
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        val icon = result?.icon
        when {
            result == null -> Unit
            full -> if (icon != null) {
                Image(icon.bitmap, app.label, Modifier.fillMaxSize().clip(CircleShape))
            }
            icon != null -> Image(
                bitmap = icon.bitmap,
                contentDescription = app.label,
                modifier = Modifier.size(glyphSize),
                colorFilter = if (icon.tint) ColorFilter.tint(c.foreground) else null,
            )
            else -> Text(
                text = app.label.take(1).uppercase(),
                color = c.foreground,
                fontSize = (size.value * 0.36f).sp,
                fontWeight = FontWeight.Light,
            )
        }
    }
}
