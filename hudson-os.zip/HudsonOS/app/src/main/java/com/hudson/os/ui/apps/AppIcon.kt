package com.hudson.os.ui.apps

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import com.hudson.os.data.apps.AppEntry

/** Loads an app icon off the main thread. Returns null until ready (or if it cannot be read). */
@Composable
fun rememberAppIcon(vm: AppsViewModel, app: AppEntry, sizePx: Int): ImageBitmap? {
    val icon by produceState<ImageBitmap?>(null, app.key, sizePx) {
        value = vm.icon(app, sizePx)
    }
    return icon
}
