package com.hudson.os.ui.orbit

import android.content.Context
import android.os.SystemClock
import android.provider.Settings
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.hudson.os.data.IconStyle
import kotlin.math.abs
import kotlin.math.exp

@Immutable
data class OrbitConfig(
    val sizeScale: Float = 1f,
    val driftDegPerSec: Float = 7f,
    val haptics: Boolean = true,
    val sound: Boolean = false,
    val reducedMotion: Boolean = false,
    val iconStyle: IconStyle = IconStyle.OUTLINE,
)

/** True when the user turned system animations off. */
fun systemReducedMotion(context: Context): Boolean =
    Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f

/**
 * Interaction and physics of the Infinite Ring, with no drawing code.
 * Angles are degrees, clockwise from the top. The ring loops forever: there is no end item.
 */
@Stable
class OrbitState(private val reducedMotion: Boolean) {
    var rotation by mutableFloatStateOf(0f)
        private set

    /** True while the finger is down or momentum is running. Idle drift does not count. */
    var moving by mutableStateOf(false)
        private set

    private var velocity = 0f
    private var dragging = false
    private var lastDragUptime = 0L

    fun beginDrag() {
        dragging = true
        velocity = 0f
        moving = true
    }

    fun drag(deltaDeg: Float, uptimeMs: Long, dtMs: Long) {
        rotation = (rotation + deltaDeg) % 360f
        val instant = deltaDeg / dtMs.toFloat() * 1000f
        velocity = (0.55f * velocity + 0.45f * instant).coerceIn(-MAX_VELOCITY, MAX_VELOCITY)
        lastDragUptime = uptimeMs
    }

    fun endDrag() {
        dragging = false
        val heldStill = SystemClock.uptimeMillis() - lastDragUptime > 90
        if (reducedMotion || heldStill) velocity = 0f
        moving = velocity != 0f
    }

    /** Advance one frame: momentum with friction first, then slow idle drift. */
    fun step(dtSec: Float, driftDegPerSec: Float) {
        if (dragging) return
        val dt = dtSec.coerceIn(0f, 0.05f)
        if (abs(velocity) > MIN_VELOCITY) {
            rotation = (rotation + velocity * dt) % 360f
            velocity *= exp(-FRICTION * dt)
            moving = true
        } else {
            velocity = 0f
            moving = false
            rotation = (rotation + driftDegPerSec * dt) % 360f
        }
    }

    /** Index of the item closest to the top. */
    fun selectedIndex(count: Int): Int {
        if (count == 0) return 0
        val step = 360f / count
        var best = 0
        var bestDistance = Float.MAX_VALUE
        for (i in 0 until count) {
            val d = abs(((rotation + i * step + 180f) % 360f + 360f) % 360f - 180f)
            if (d < bestDistance) {
                bestDistance = d
                best = i
            }
        }
        return best
    }

    private companion object {
        const val MAX_VELOCITY = 1500f
        const val MIN_VELOCITY = 4f
        const val FRICTION = 2.4f
    }
}
