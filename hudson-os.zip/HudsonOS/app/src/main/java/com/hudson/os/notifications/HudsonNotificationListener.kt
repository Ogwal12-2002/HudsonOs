package com.hudson.os.notifications

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class HudsonNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() = publish()

    override fun onListenerDisconnected() = NotificationStore.set(emptyMap())

    override fun onNotificationPosted(sbn: StatusBarNotification?) = publish()

    override fun onNotificationRemoved(sbn: StatusBarNotification?) = publish()

    private fun publish() {
        val active: Array<StatusBarNotification>? = try {
            activeNotifications
        } catch (e: SecurityException) {
            null
        }
        if (active == null) return
        val counts = HashMap<String, Int>()
        for (sbn in active) {
            val summary = sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0
            if (summary || sbn.isOngoing || sbn.packageName == packageName) continue
            counts[sbn.packageName] = (counts[sbn.packageName] ?: 0) + 1
        }
        NotificationStore.set(counts)
    }
}
