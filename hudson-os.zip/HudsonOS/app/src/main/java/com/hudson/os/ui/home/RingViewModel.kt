package com.hudson.os.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hudson.os.data.prefs.FavoritesStore
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** keys == null means the user never edited the ring. The holder itself is null until loaded. */
data class SavedFavorites(val keys: List<String>?)

class RingViewModel(application: Application) : AndroidViewModel(application) {
    private val store = FavoritesStore(application)

    val saved: StateFlow<SavedFavorites?> = store.favorites
        .map { SavedFavorites(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    fun save(keys: List<String>) {
        viewModelScope.launch { store.save(keys) }
    }
}
