package com.hudson.os.ui.apps

import com.hudson.os.data.apps.AppEntry
import java.text.Normalizer

private val accents = Regex("\\p{Mn}+")

private fun fold(text: String): String =
    Normalizer.normalize(text, Normalizer.Form.NFD).replace(accents, "").lowercase()

/** Case- and accent-insensitive: "ecran" finds "Écran". */
fun filterApps(apps: List<AppEntry>, query: String): List<AppEntry> {
    val q = fold(query.trim())
    return if (q.isEmpty()) apps else apps.filter { fold(it.label).contains(q) }
}
