package com.hudson.os.ui.theme

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

enum class GlyphKind { ChevronUp, Close, Grid, List, Gear, Bell, Play, Pause, Next, Prev, Search, Plus, Check }

/** Thin line icons drawn in code, so the launcher needs no icon library. */
@Composable
fun Glyph(kind: GlyphKind, color: Color, modifier: Modifier = Modifier.size(20.dp)) {
    Canvas(modifier) {
        val s = size.minDimension / 24f
        val w = 1.6f * s
        val stroke = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun pt(x: Float, y: Float) = Offset(x * s, y * s)
        fun line(x1: Float, y1: Float, x2: Float, y2: Float, width: Float = w) =
            drawLine(color, pt(x1, y1), pt(x2, y2), width, StrokeCap.Round)
        when (kind) {
            GlyphKind.ChevronUp -> drawPath(
                Path().apply { moveTo(6 * s, 15 * s); lineTo(12 * s, 9 * s); lineTo(18 * s, 15 * s) },
                color, style = stroke,
            )
            GlyphKind.Close -> { line(6f, 6f, 18f, 18f); line(18f, 6f, 6f, 18f) }
            GlyphKind.Grid -> {
                for ((x, y) in listOf(4f to 4f, 14f to 4f, 4f to 14f, 14f to 14f)) {
                    drawRect(color, pt(x, y), Size(6 * s, 6 * s), style = stroke)
                }
            }
            GlyphKind.List -> { line(5f, 7f, 19f, 7f); line(5f, 12f, 19f, 12f); line(5f, 17f, 19f, 17f) }
            GlyphKind.Gear -> {
                drawCircle(color, radius = 3.2f * s, center = pt(12f, 12f), style = stroke)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val ca = cos(a).toFloat()
                    val sa = sin(a).toFloat()
                    line(12f + 6.2f * ca, 12f + 6.2f * sa, 12f + 9.2f * ca, 12f + 9.2f * sa)
                }
            }
            GlyphKind.Bell -> {
                val bell = Path().apply {
                    moveTo(6 * s, 17 * s)
                    lineTo(6 * s, 11 * s)
                    arcTo(Rect(6 * s, 5 * s, 18 * s, 17 * s), 180f, 180f, false)
                    lineTo(18 * s, 17 * s)
                    close()
                }
                drawPath(bell, color, style = stroke)
                line(10f, 20.5f, 14f, 20.5f)
            }
            GlyphKind.Play -> drawPath(
                Path().apply { moveTo(8 * s, 5 * s); lineTo(19 * s, 12 * s); lineTo(8 * s, 19 * s); close() },
                color,
            )
            GlyphKind.Pause -> { line(9f, 5f, 9f, 19f, 2.6f * s); line(15f, 5f, 15f, 19f, 2.6f * s) }
            GlyphKind.Next -> {
                drawPath(Path().apply { moveTo(6 * s, 5 * s); lineTo(15 * s, 12 * s); lineTo(6 * s, 19 * s); close() }, color)
                line(18f, 5f, 18f, 19f, 2.2f * s)
            }
            GlyphKind.Prev -> {
                drawPath(Path().apply { moveTo(18 * s, 5 * s); lineTo(9 * s, 12 * s); lineTo(18 * s, 19 * s); close() }, color)
                line(6f, 5f, 6f, 19f, 2.2f * s)
            }
            GlyphKind.Search -> {
                drawCircle(color, radius = 5.5f * s, center = pt(10.5f, 10.5f), style = stroke)
                line(14.5f, 14.5f, 19f, 19f)
            }
            GlyphKind.Plus -> { line(12f, 5f, 12f, 19f); line(5f, 12f, 19f, 12f) }
            GlyphKind.Check -> drawPath(
                Path().apply { moveTo(5 * s, 12 * s); lineTo(10 * s, 17 * s); lineTo(19 * s, 7 * s) },
                color, style = stroke,
            )
        }
        Unit
    }
}

@Composable
fun GlyphButton(
    kind: GlyphKind,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    bordered: Boolean = true,
) {
    val c = Hudson.colors
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .then(if (bordered) Modifier.border(1.dp, c.outline, CircleShape) else Modifier)
            .clickable(onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        Glyph(kind, c.foreground, Modifier.size(size * 0.45f))
    }
}
