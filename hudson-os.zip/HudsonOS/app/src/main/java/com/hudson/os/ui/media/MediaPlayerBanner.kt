package com.hudson.os.ui.media

import android.os.SystemClock
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import com.hudson.os.R
import com.hudson.os.media.MediaUi
import com.hudson.os.ui.theme.GlyphButton
import com.hudson.os.ui.theme.GlyphKind
import com.hudson.os.ui.theme.Hudson
import kotlinx.coroutines.delay

private fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(total / 60, total % 60)
}

/** Compact banner: artwork, title, artist, progress, and only the controls the session supports. */
@Composable
fun MediaPlayerBanner(
    media: MediaUi,
    onPrevious: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = Hudson.colors
    val lifecycleOwner = LocalLifecycleOwner.current
    var now by remember(media) { mutableLongStateOf(SystemClock.elapsedRealtime()) }

    // Progress ticks once a second, only while playing and while the launcher is visible.
    LaunchedEffect(media.isPlaying, lifecycleOwner) {
        if (media.isPlaying) {
            lifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    now = SystemClock.elapsedRealtime()
                    delay(1000)
                }
            }
        }
    }

    val hasDuration = media.durationMs > 0
    val raw = if (media.isPlaying) {
        media.positionMs + ((now - media.updateTime) * media.speed).toLong()
    } else {
        media.positionMs
    }
    val position = raw.coerceIn(0L, if (hasDuration) media.durationMs else Long.MAX_VALUE)
    val fraction = if (hasDuration) (position.toFloat() / media.durationMs).coerceIn(0f, 1f) else 0f
    val shape = RoundedCornerShape(28.dp)

    Row(
        modifier
            .fillMaxWidth()
            .background(c.background.copy(alpha = 0.6f), shape)
            .border(1.dp, c.outline, shape)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)).background(c.outlineDim),
            contentAlignment = Alignment.Center,
        ) {
            if (media.art != null) {
                Image(media.art, null, Modifier.size(56.dp), contentScale = ContentScale.Crop)
            } else {
                Text("♪", color = c.foreground, fontSize = 22.sp)
            }
        }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        media.title,
                        color = c.foreground,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Light,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(media.artist, color = c.dim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (media.canPrevious) {
                    GlyphButton(GlyphKind.Prev, stringResource(R.string.cd_previous), onPrevious, size = 36.dp, bordered = false)
                }
                if (media.canPlayPause) {
                    GlyphButton(
                        if (media.isPlaying) GlyphKind.Pause else GlyphKind.Play,
                        stringResource(if (media.isPlaying) R.string.cd_pause else R.string.cd_play),
                        onPlayPause,
                        size = 44.dp,
                    )
                }
                if (media.canNext) {
                    GlyphButton(GlyphKind.Next, stringResource(R.string.cd_next), onNext, size = 36.dp, bordered = false)
                }
            }
            if (hasDuration) {
                Box(Modifier.fillMaxWidth().padding(top = 6.dp).height(10.dp), contentAlignment = Alignment.CenterStart) {
                    Box(Modifier.fillMaxWidth().height(2.dp).background(c.outlineDim))
                    Box(Modifier.fillMaxWidth(fraction).height(2.dp).background(c.foreground))
                    Box(Modifier.fillMaxWidth(fraction), contentAlignment = Alignment.CenterEnd) {
                        Box(Modifier.size(8.dp).background(c.foreground, CircleShape))
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatTime(position), color = c.dim, fontSize = 11.sp)
                    Text(formatTime(media.durationMs), color = c.dim, fontSize = 11.sp)
                }
            }
        }
    }
}
