package com.hudson.os.ui.ring

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import com.hudson.os.data.apps.AppEntry
import com.hudson.os.ui.apps.AppsViewModel
import com.hudson.os.ui.apps.rememberAppIcon
import com.hudson.os.ui.theme.HudsonColors
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.flow.first

/** Position of item [index] relative to the ring centre, in px. Angle 0 is the top, clockwise. */
private fun itemOffset(index: Int, count: Int, rotationDeg: Float, radiusPx: Float): Offset {
    val a = Math.toRadians((rotationDeg + index * 360f / count).toDouble())
    return Offset((radiusPx * sin(a)).toFloat(), (-radiusPx * cos(a)).toFloat())
}

@Composable
fun InfiniteRing(
    apps: List<AppEntry>,
    vm: AppsViewModel,
    active: Boolean,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
    modifier: Modifier = Modifier,
    config: RingConfig = RingConfig(),
) {
    val state = remember(config.reducedMotion) { RingState(config.reducedMotion) }
    val intro = remember { Animatable(if (config.reducedMotion) 1f else 0f) }
    val haptic = LocalHapticFeedback.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val count = apps.size
    val step = if (count > 0) 360f / count else 360f
    val drift = if (config.reducedMotion || !active) 0f else config.driftDegPerSec
    val selected by remember(count) { derivedStateOf { state.selectedIndex(count) } }

    // One short spin-in when the home screen first appears.
    LaunchedEffect(Unit) {
        if (intro.value < 1f) intro.animateTo(1f, tween(1300, easing = FastOutSlowInEasing))
    }

    // Frame loop. It only runs while the launcher is visible (STARTED), and it sleeps
    // completely when nothing is moving and drift is off.
    LaunchedEffect(lifecycleOwner, drift) {
        lifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
            var last = withFrameNanos { it }
            while (true) {
                if (!state.moving && drift <= 0f) {
                    snapshotFlow { state.moving }.first { it }
                    last = withFrameNanos { it }
                }
                val now = withFrameNanos { it }
                state.step((now - last) / 1_000_000_000f, drift)
                last = now
            }
        }
    }

    // A light tick each time a new app passes the top, only while the user is spinning it.
    LaunchedEffect(selected) {
        if (config.haptics && state.moving) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
    }

    BoxWithConstraints(modifier) {
        val side = minOf(maxWidth, maxHeight)
        val radius = side * 0.36f * config.sizeScale
        val itemSize = (side * 0.16f).coerceIn(42.dp, 66.dp)
        val iconPx = with(LocalDensity.current) { (itemSize * 0.62f).roundToPx() }

        Box(
            Modifier
                .fillMaxSize()
                // Tap launches, long press opens the actions.
                .pointerInput(apps, radius, itemSize) {
                    fun hit(p: Offset): AppEntry? {
                        if (apps.isEmpty()) return null
                        val e = intro.value
                        val c = Offset(size.width / 2f, size.height / 2f)
                        val half = itemSize.toPx() * 0.6f
                        val index = apps.indices.firstOrNull { i ->
                            val o = itemOffset(i, apps.size, state.rotation - (1f - e) * 200f, radius.toPx() * e)
                            (c + o - p).getDistance() <= half
                        }
                        return index?.let { apps[it] }
                    }
                    detectTapGestures(
                        onTap = { p -> hit(p)?.let(onLaunch) },
                        onLongPress = { p ->
                            hit(p)?.let {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                onLongPress(it)
                            }
                        },
                    )
                }
                // Drag or flick to rotate, in either direction.
                .pointerInput(state) {
                    fun angleOf(p: Offset): Float {
                        val dx = p.x - size.width / 2f
                        val dy = size.height / 2f - p.y
                        return Math.toDegrees(atan2(dx.toDouble(), dy.toDouble())).toFloat()
                    }
                    var lastAngle = 0f
                    detectDragGestures(
                        onDragStart = { p ->
                            lastAngle = angleOf(p)
                            state.beginDrag()
                        },
                        onDrag = { change, _ ->
                            val a = angleOf(change.position)
                            var d = a - lastAngle
                            if (d > 180f) d -= 360f
                            if (d < -180f) d += 360f
                            lastAngle = a
                            val dt = (change.uptimeMillis - change.previousUptimeMillis).coerceAtLeast(1L)
                            state.drag(d, change.uptimeMillis, dt)
                            change.consume()
                        },
                        onDragEnd = { state.endDrag() },
                        onDragCancel = { state.endDrag() },
                    )
                },
        ) {
            // Thin circular borders: the outer track and a slowly turning dashed inner ring.
            Canvas(Modifier.fillMaxSize()) {
                val r = radius.toPx() * intro.value
                drawCircle(HudsonColors.Outline, radius = r, style = Stroke(width = 1.dp.toPx()))
                drawCircle(
                    HudsonColors.OutlineDim,
                    radius = r * 0.52f,
                    style = Stroke(
                        width = 1.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(
                            floatArrayOf(3.dp.toPx(), 9.dp.toPx()),
                            -state.rotation * 0.8f,
                        ),
                    ),
                )
            }

            Crossfade(
                targetState = apps.getOrNull(selected)?.label.orEmpty(),
                modifier = Modifier.align(Alignment.Center),
                label = "ringLabel",
            ) { label ->
                Text(
                    text = label,
                    color = HudsonColors.Foreground,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Light,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    modifier = Modifier.widthIn(max = side * 0.45f),
                )
            }

            apps.forEachIndexed { i, app ->
                key(app.key) {
                    val icon = rememberAppIcon(vm, app, iconPx)
                    Box(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(itemSize)
                            .graphicsLayer {
                                val e = intro.value
                                val spin = state.rotation - (1f - e) * 200f
                                val o = itemOffset(i, count, spin, radius.toPx() * e)
                                translationX = o.x
                                translationY = o.y
                                val d = ((spin + i * step + 180f) % 360f + 360f) % 360f - 180f
                                val p = (1f - abs(d) / step).coerceIn(0f, 1f)
                                val s = 1f + 0.22f * p
                                scaleX = s
                                scaleY = s
                                alpha = e * (0.6f + 0.4f * p)
                            }
                            .background(HudsonColors.Background.copy(alpha = 0.7f), CircleShape)
                            .border(
                                1.dp,
                                if (i == selected) HudsonColors.Foreground else HudsonColors.Outline,
                                CircleShape,
                            )
                            .padding(itemSize * 0.17f),
                    ) {
                        if (icon != null) {
                            Image(bitmap = icon, contentDescription = app.label, modifier = Modifier.fillMaxSize())
                        }
                    }
                }
            }
        }
    }
}
