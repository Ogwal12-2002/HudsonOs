package com.hudson.os.ui.apps

import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.hudson.os.R
import com.hudson.os.data.apps.AppEntry
import com.hudson.os.ui.theme.HudsonColors

/** Stage 2 list of installed apps. Search, list/grid toggle and ring shortcuts arrive in Stage 4. */
@Composable
fun AppsScreen(
    vm: AppsViewModel,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
    modifier: Modifier = Modifier,
) {
    val state by vm.state.collectAsStateWithLifecycle()
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(HudsonColors.Background.copy(alpha = 0.97f))
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.Center,
    ) {
        when (val s = state) {
            is AppsUiState.Loading -> CircularProgressIndicator(
                color = HudsonColors.Foreground,
                strokeWidth = 1.dp,
                modifier = Modifier.size(32.dp),
            )
            is AppsUiState.Error -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(stringResource(R.string.apps_error), color = HudsonColors.Dim)
                TextButton(onClick = vm::refresh) {
                    Text(stringResource(R.string.apps_retry), color = HudsonColors.Foreground)
                }
            }
            is AppsUiState.Ready ->
                if (s.apps.isEmpty()) {
                    Text(stringResource(R.string.apps_empty), color = HudsonColors.Dim)
                } else {
                    AppGrid(s.apps, vm, onLaunch, onLongPress)
                }
        }
    }
}

@Composable
private fun AppGrid(
    apps: List<AppEntry>,
    vm: AppsViewModel,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(76.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        items(apps, key = { it.key }) { app -> AppCell(app, vm, onLaunch, onLongPress) }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppCell(
    app: AppEntry,
    vm: AppsViewModel,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
) {
    val iconPx = with(LocalDensity.current) { 52.dp.roundToPx() }
    val bitmap = rememberAppIcon(vm, app, iconPx)
    Column(
        modifier = Modifier
            .combinedClickable(onClick = { onLaunch(app) }, onLongClick = { onLongPress(app) })
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (bitmap != null) {
            Image(bitmap = bitmap, contentDescription = null, modifier = Modifier.size(52.dp))
        } else {
            // Consistent outline fallback while loading, or when an icon cannot be read.
            Box(Modifier.size(52.dp).border(1.dp, HudsonColors.Outline, CircleShape))
        }
        Text(
            text = app.label,
            color = HudsonColors.Foreground,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}
