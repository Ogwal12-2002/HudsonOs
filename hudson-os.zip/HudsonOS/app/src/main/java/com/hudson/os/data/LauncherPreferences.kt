package com.hudson.os.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore

enum class ThemeId { VOID, GHOST, ICE, NEON, PAPER }
enum class IconStyle { OUTLINE, MONOCHROME, ORIGINAL }
enum class DrawerLayout { GRID, LIST }
enum class ClockFormat { SYSTEM, H24, H12 }
enum class ClockSize { SMALL, MEDIUM, LARGE }
enum class AppLanguage { SYSTEM, EN, FR }

data class LauncherSettings(
    val theme: ThemeId = ThemeId.VOID,
    val iconStyle: IconStyle = IconStyle.OUTLINE,
    val ringSize: Float = 1f,
    val ringSpeed: Int = 3,
    val rotationSound: Boolean = false,
    val haptics: Boolean = true,
    val clockFormat: ClockFormat = ClockFormat.SYSTEM,
    val clockSize: ClockSize = ClockSize.MEDIUM,
    val showDate: Boolean = true,
    val showNotifications: Boolean = true,
    val showMedia: Boolean = true,
    val drawerLayout: DrawerLayout = DrawerLayout.GRID,
    val language: AppLanguage = AppLanguage.SYSTEM,
    /** null = follow the system animation setting. */
    val reducedMotion: Boolean? = null,
    val wallpaperDim: Float = 0.3f,
    /** 0 = no wallpaper; otherwise the time it was chosen (used to reload the image). */
    val wallpaperStamp: Long = 0L,
    /** Component names of the ring shortcuts; null = never edited (defaults apply). */
    val favorites: List<String>? = null,
)

internal val Context.hudsonDataStore: DataStore<Preferences> by preferencesDataStore(name = "hudson_prefs")

object Keys {
    val THEME = stringPreferencesKey("theme")
    val ICON_STYLE = stringPreferencesKey("icon_style")
    val RING_SIZE = floatPreferencesKey("ring_size")
    val RING_SPEED = intPreferencesKey("ring_speed")
    val ROTATION_SOUND = booleanPreferencesKey("rotation_sound")
    val HAPTICS = booleanPreferencesKey("haptics")
    val CLOCK_FORMAT = stringPreferencesKey("clock_format")
    val CLOCK_SIZE = stringPreferencesKey("clock_size")
    val SHOW_DATE = booleanPreferencesKey("show_date")
    val SHOW_NOTIFICATIONS = booleanPreferencesKey("show_notifications")
    val SHOW_MEDIA = booleanPreferencesKey("show_media")
    val DRAWER_LAYOUT = stringPreferencesKey("drawer_layout")
    val LANGUAGE = stringPreferencesKey("language")
    val REDUCED_MOTION = booleanPreferencesKey("reduced_motion")
    val WALLPAPER_DIM = floatPreferencesKey("wallpaper_dim")
    val WALLPAPER_STAMP = longPreferencesKey("wallpaper_stamp")
    val FAVORITES = stringPreferencesKey("ring_favorites")
}

private inline fun <reified E : Enum<E>> Preferences.enumOf(key: Preferences.Key<String>, default: E): E =
    this[key]?.let { name -> enumValues<E>().firstOrNull { it.name == name } } ?: default

fun Preferences.toSettings(): LauncherSettings = LauncherSettings(
    theme = enumOf(Keys.THEME, ThemeId.VOID),
    iconStyle = enumOf(Keys.ICON_STYLE, IconStyle.OUTLINE),
    ringSize = (this[Keys.RING_SIZE] ?: 1f).coerceIn(0.7f, 1.15f),
    ringSpeed = (this[Keys.RING_SPEED] ?: 3).coerceIn(0, 10),
    rotationSound = this[Keys.ROTATION_SOUND] ?: false,
    haptics = this[Keys.HAPTICS] ?: true,
    clockFormat = enumOf(Keys.CLOCK_FORMAT, ClockFormat.SYSTEM),
    clockSize = enumOf(Keys.CLOCK_SIZE, ClockSize.MEDIUM),
    showDate = this[Keys.SHOW_DATE] ?: true,
    showNotifications = this[Keys.SHOW_NOTIFICATIONS] ?: true,
    showMedia = this[Keys.SHOW_MEDIA] ?: true,
    drawerLayout = enumOf(Keys.DRAWER_LAYOUT, DrawerLayout.GRID),
    language = enumOf(Keys.LANGUAGE, AppLanguage.SYSTEM),
    reducedMotion = this[Keys.REDUCED_MOTION],
    wallpaperDim = (this[Keys.WALLPAPER_DIM] ?: 0.3f).coerceIn(0f, 0.8f),
    wallpaperStamp = this[Keys.WALLPAPER_STAMP] ?: 0L,
    favorites = this[Keys.FAVORITES]?.split('\n')?.filter { it.isNotEmpty() },
)
