package com.hudson.os.settings

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import com.hudson.os.data.Keys
import com.hudson.os.data.LauncherSettings
import com.hudson.os.data.hudsonDataStore
import com.hudson.os.data.toSettings
import java.io.File
import java.io.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

/** All launcher settings live in one local DataStore. Nothing is uploaded anywhere. */
class SettingsRepository(context: Context) {
    private val appContext = context.applicationContext
    private val store = appContext.hudsonDataStore

    val settings: Flow<LauncherSettings> = store.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { it.toSettings() }

    suspend fun <T> set(key: Preferences.Key<T>, value: T) {
        store.edit { it[key] = value }
    }

    suspend fun saveFavorites(keys: List<String>) = set(Keys.FAVORITES, keys.joinToString("\n"))

    suspend fun resetRing() {
        store.edit { it.remove(Keys.FAVORITES) }
    }

    fun wallpaperFile(): File = File(appContext.filesDir, "wallpaper.jpg")

    /** Copies the chosen photo into app storage (picker access is temporary). */
    suspend fun importWallpaper(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val bitmap = decode(uri, 2400) ?: return@withContext false
            wallpaperFile().outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            store.edit { it[Keys.WALLPAPER_STAMP] = System.currentTimeMillis() }
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun clearWallpaper() {
        withContext(Dispatchers.IO) { wallpaperFile().delete() }
        set(Keys.WALLPAPER_STAMP, 0L)
    }

    private fun decode(uri: Uri, maxSide: Int): Bitmap? {
        val resolver = appContext.contentResolver
        if (Build.VERSION.SDK_INT >= 28) {
            return ImageDecoder.decodeBitmap(ImageDecoder.createSource(resolver, uri)) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val scale = minOf(1f, maxSide.toFloat() / maxOf(info.size.width, info.size.height))
                decoder.setTargetSize(
                    (info.size.width * scale).toInt().coerceAtLeast(1),
                    (info.size.height * scale).toInt().coerceAtLeast(1),
                )
            }
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    }
}
