package com.hudson.os.ui.settings

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hudson.os.R
import com.hudson.os.data.AppLanguage
import com.hudson.os.data.ClockFormat
import com.hudson.os.data.ClockSize
import com.hudson.os.data.DrawerLayout
import com.hudson.os.data.IconStyle
import com.hudson.os.data.Keys
import com.hudson.os.data.LauncherSettings
import com.hudson.os.data.ThemeId
import com.hudson.os.settings.SettingsViewModel
import com.hudson.os.ui.theme.GlyphButton
import com.hudson.os.ui.theme.GlyphKind
import com.hudson.os.ui.theme.Hudson
import kotlin.math.roundToInt

/** Every control here changes real behaviour and is saved with DataStore. */
@Composable
fun SettingsScreen(
    settings: LauncherSettings,
    vm: SettingsViewModel,
    accessGranted: Boolean,
    reducedMotion: Boolean,
    onRequestAccess: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = Hudson.colors
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            vm.importWallpaper(uri) { ok ->
                if (!ok) Toast.makeText(context, R.string.wallpaper_failed, Toast.LENGTH_SHORT).show()
            }
        }
    }

    Column(
        modifier
            .fillMaxSize()
            .background(c.background.copy(alpha = 0.98f))
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 20.dp, vertical = 12.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                stringResource(R.string.settings_title),
                color = c.foreground,
                fontSize = 26.sp,
                fontWeight = FontWeight.Light,
                modifier = Modifier.weight(1f),
            )
            GlyphButton(GlyphKind.Close, stringResource(R.string.cd_close), onClose)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(top = 8.dp, bottom = 24.dp)) {
            Section(R.string.section_look)
            ChoiceRow(
                stringResource(R.string.set_theme),
                listOf(
                    ThemeId.VOID to stringResource(R.string.theme_void),
                    ThemeId.GHOST to stringResource(R.string.theme_ghost),
                    ThemeId.ICE to stringResource(R.string.theme_ice),
                    ThemeId.NEON to stringResource(R.string.theme_neon),
                    ThemeId.PAPER to stringResource(R.string.theme_paper),
                ),
                settings.theme,
            ) { vm.set(Keys.THEME, it.name) }
            ChoiceRow(
                stringResource(R.string.set_icon_style),
                listOf(
                    IconStyle.OUTLINE to stringResource(R.string.icon_outline),
                    IconStyle.MONOCHROME to stringResource(R.string.icon_mono),
                    IconStyle.ORIGINAL to stringResource(R.string.icon_original),
                ),
                settings.iconStyle,
            ) { vm.set(Keys.ICON_STYLE, it.name) }
            Text(stringResource(R.string.set_wallpaper), color = c.foreground, fontSize = 15.sp, modifier = Modifier.padding(top = 10.dp))
            Row(Modifier.padding(top = 8.dp, bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionChip(stringResource(R.string.wallpaper_choose)) {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                if (settings.wallpaperStamp != 0L) {
                    ActionChip(stringResource(R.string.wallpaper_remove)) { vm.clearWallpaper() }
                }
            }
            SliderRow(stringResource(R.string.set_wallpaper_dim), settings.wallpaperDim, 0f..0.8f) {
                vm.set(Keys.WALLPAPER_DIM, it)
            }

            Section(R.string.section_ring)
            SliderRow(stringResource(R.string.set_ring_size), settings.ringSize, 0.7f..1.15f) {
                vm.set(Keys.RING_SIZE, it)
            }
            SliderRow(stringResource(R.string.set_ring_speed), settings.ringSpeed.toFloat(), 0f..10f, steps = 9) {
                vm.set(Keys.RING_SPEED, it.roundToInt())
            }
            SwitchRow(stringResource(R.string.set_sound), settings.rotationSound) { vm.set(Keys.ROTATION_SOUND, it) }
            SwitchRow(stringResource(R.string.set_haptics), settings.haptics) { vm.set(Keys.HAPTICS, it) }
            SwitchRow(stringResource(R.string.set_reduced_motion), reducedMotion) { vm.set(Keys.REDUCED_MOTION, it) }
            val resetDone = stringResource(R.string.ring_reset_done)
            Row(Modifier.padding(top = 8.dp)) {
                ActionChip(stringResource(R.string.set_reset_ring)) {
                    vm.resetRing()
                    Toast.makeText(context, resetDone, Toast.LENGTH_SHORT).show()
                }
            }

            Section(R.string.section_home)
            ChoiceRow(
                stringResource(R.string.set_clock_format),
                listOf(
                    ClockFormat.SYSTEM to stringResource(R.string.clock_system),
                    ClockFormat.H24 to stringResource(R.string.clock_24),
                    ClockFormat.H12 to stringResource(R.string.clock_12),
                ),
                settings.clockFormat,
            ) { vm.set(Keys.CLOCK_FORMAT, it.name) }
            ChoiceRow(
                stringResource(R.string.set_clock_size),
                listOf(
                    ClockSize.SMALL to stringResource(R.string.size_small),
                    ClockSize.MEDIUM to stringResource(R.string.size_medium),
                    ClockSize.LARGE to stringResource(R.string.size_large),
                ),
                settings.clockSize,
            ) { vm.set(Keys.CLOCK_SIZE, it.name) }
            SwitchRow(stringResource(R.string.set_show_date), settings.showDate) { vm.set(Keys.SHOW_DATE, it) }
            SwitchRow(stringResource(R.string.set_show_notifications), settings.showNotifications) {
                vm.set(Keys.SHOW_NOTIFICATIONS, it)
            }
            SwitchRow(stringResource(R.string.set_show_media), settings.showMedia) { vm.set(Keys.SHOW_MEDIA, it) }
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.set_notif_access), color = c.foreground, fontSize = 15.sp)
                    Text(
                        stringResource(if (accessGranted) R.string.notif_access_on else R.string.notif_access_off),
                        color = c.dim,
                        fontSize = 12.sp,
                    )
                }
                ActionChip(stringResource(R.string.notif_access_open), onRequestAccess)
            }

            Section(R.string.section_system)
            ChoiceRow(
                stringResource(R.string.set_drawer_layout),
                listOf(
                    DrawerLayout.GRID to stringResource(R.string.layout_grid),
                    DrawerLayout.LIST to stringResource(R.string.layout_list),
                ),
                settings.drawerLayout,
            ) { vm.set(Keys.DRAWER_LAYOUT, it.name) }
            ChoiceRow(
                stringResource(R.string.set_language),
                listOf(
                    AppLanguage.SYSTEM to stringResource(R.string.lang_system),
                    AppLanguage.EN to stringResource(R.string.lang_en),
                    AppLanguage.FR to stringResource(R.string.lang_fr),
                ),
                settings.language,
            ) { vm.set(Keys.LANGUAGE, it.name) }
        }
    }
}

@Composable
private fun Section(titleRes: Int) {
    Text(
        stringResource(titleRes),
        color = Hudson.colors.dim,
        fontSize = 12.sp,
        letterSpacing = 2.sp,
        modifier = Modifier.padding(top = 22.dp, bottom = 4.dp),
    )
}

@Composable
private fun <T> ChoiceRow(label: String, options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    val c = Hudson.colors
    Column(Modifier.padding(vertical = 10.dp)) {
        Text(label, color = c.foreground, fontSize = 15.sp)
        Row(
            Modifier.padding(top = 8.dp).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            options.forEach { (value, text) ->
                val on = value == selected
                Text(
                    text,
                    color = if (on) c.background else c.foreground,
                    fontSize = 13.sp,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(if (on) c.foreground else Color.Transparent)
                        .border(1.dp, if (on) c.foreground else c.outline, CircleShape)
                        .clickable { onSelect(value) }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                )
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = Hudson.colors
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = c.foreground, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = c.background,
                checkedTrackColor = c.accent,
                uncheckedThumbColor = c.dim,
                uncheckedTrackColor = Color.Transparent,
                uncheckedBorderColor = c.outline,
            ),
        )
    }
}

@Composable
private fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int = 0,
    onCommit: (Float) -> Unit,
) {
    val c = Hudson.colors
    var local by remember(value) { mutableFloatStateOf(value) }
    Column(Modifier.padding(top = 10.dp)) {
        Text(label, color = c.foreground, fontSize = 15.sp)
        Slider(
            value = local,
            onValueChange = { local = it },
            onValueChangeFinished = { onCommit(local) },
            valueRange = range,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = c.foreground,
                activeTrackColor = c.accent,
                inactiveTrackColor = c.outlineDim,
            ),
        )
    }
}

@Composable
private fun ActionChip(text: String, onClick: () -> Unit) {
    val c = Hudson.colors
    Text(
        text,
        color = c.foreground,
        fontSize = 13.sp,
        modifier = Modifier
            .clip(CircleShape)
            .border(1.dp, c.outline, CircleShape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
    )
}
