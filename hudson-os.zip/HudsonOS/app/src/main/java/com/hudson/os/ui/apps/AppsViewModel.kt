package com.hudson.os.ui.apps

import android.app.Application
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hudson.os.data.apps.AppEntry
import com.hudson.os.data.apps.InstalledAppsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface AppsUiState {
    data object Loading : AppsUiState
    data object Error : AppsUiState
    data class Ready(val apps: List<AppEntry>) : AppsUiState
}

class AppsViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = InstalledAppsRepository(application)
    private val _state = MutableStateFlow<AppsUiState>(AppsUiState.Loading)
    val state: StateFlow<AppsUiState> = _state.asStateFlow()

    /** Called every time the launcher becomes visible, so installs and removals show up. */
    fun refresh() {
        viewModelScope.launch {
            try {
                _state.value = AppsUiState.Ready(repository.load())
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (_state.value !is AppsUiState.Ready) _state.value = AppsUiState.Error
            }
        }
    }

    suspend fun icon(entry: AppEntry, sizePx: Int): ImageBitmap? = repository.icon(entry, sizePx)

    fun launch(entry: AppEntry): Boolean = repository.launch(entry)
}
