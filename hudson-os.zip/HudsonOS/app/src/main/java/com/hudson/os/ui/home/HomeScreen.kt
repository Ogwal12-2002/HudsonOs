package com.hudson.os.ui.home

import android.content.Intent
import android.graphics.BitmapFactory
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hudson.os.R
import com.hudson.os.data.DrawerLayout
import com.hudson.os.data.Keys
import com.hudson.os.data.LauncherSettings
import com.hudson.os.data.apps.AppEntry
import com.hudson.os.media.MediaSessionRepository
import com.hudson.os.media.MediaUi
import com.hudson.os.notifications.NotificationStore
import com.hudson.os.notifications.notificationAccessGranted
import com.hudson.os.settings.SettingsViewModel
import com.hudson.os.ui.apps.AppActionsDialog
import com.hudson.os.ui.apps.AppDrawerScreen
import com.hudson.os.ui.apps.AppsUiState
import com.hudson.os.ui.apps.AppsViewModel
import com.hudson.os.ui.media.MediaPlayerBanner
import com.hudson.os.ui.orbit.InfiniteRing
import com.hudson.os.ui.orbit.OrbitConfig
import com.hudson.os.ui.orbit.systemReducedMotion
import com.hudson.os.ui.settings.SettingsScreen
import com.hudson.os.ui.theme.Glyph
import com.hudson.os.ui.theme.GlyphKind
import com.hudson.os.ui.theme.Hudson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val DEFAULT_RING_SIZE = 8
private const val MAX_RING_SIZE = 12

private enum class Layer { HOME, DRAWER, SETTINGS }

@Composable
fun HomeScreen(
    homeSignal: Int,
    settings: LauncherSettings,
    settingsVm: SettingsViewModel,
    modifier: Modifier = Modifier,
    appsVm: AppsViewModel = viewModel(),
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val c = Hudson.colors
    var layer by rememberSaveable { mutableStateOf(Layer.HOME) }
    var menuApp by remember { mutableStateOf<AppEntry?>(null) }
    var showAccessDialog by remember { mutableStateOf(false) }
    var access by remember { mutableStateOf(notificationAccessGranted(context)) }
    var media by remember { mutableStateOf<MediaUi?>(null) }
    val mediaRepo = remember { MediaSessionRepository(context) }

    val appsState by appsVm.state.collectAsStateWithLifecycle()
    val counts by NotificationStore.counts.collectAsStateWithLifecycle()
    val allApps = (appsState as? AppsUiState.Ready)?.apps.orEmpty()
    val appsReady = appsState is AppsUiState.Ready

    val ringApps = remember(settings.favorites, allApps) {
        val keys = settings.favorites ?: allApps.take(DEFAULT_RING_SIZE).map { it.key }
        val byKey = allApps.associateBy { it.key }
        keys.mapNotNull { byKey[it] }
    }
    val ringKeys = ringApps.map { it.key }
    val notifItems = remember(counts, allApps) {
        counts.entries.sortedByDescending { it.value }
            .mapNotNull { (pkg, n) -> allApps.firstOrNull { it.component.packageName == pkg }?.let { it to n } }
            .take(5)
    }
    val systemReduced = remember { systemReducedMotion(context) }
    val reduced = settings.reducedMotion ?: systemReduced
    val orbit = OrbitConfig(
        sizeScale = settings.ringSize,
        driftDegPerSec = settings.ringSpeed * 2.4f,
        haptics = settings.haptics,
        sound = settings.rotationSound,
        reducedMotion = reduced,
        iconStyle = settings.iconStyle,
    )

    // Reload apps and re-check notification access each time the launcher becomes visible.
    LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
            appsVm.refresh()
            access = notificationAccessGranted(context)
        }
    }
    // Media session: only observed while visible, and only when access is granted and enabled.
    LaunchedEffect(lifecycleOwner, access, settings.showMedia) {
        if (!access || !settings.showMedia) {
            media = null
            return@LaunchedEffect
        }
        lifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
            mediaRepo.observe().collect { media = it }
        }
    }
    // Pressing Home returns to the home screen from anywhere.
    LaunchedEffect(homeSignal) {
        if (homeSignal > 0) {
            layer = Layer.HOME
            menuApp = null
        }
    }
    BackHandler(enabled = layer != Layer.HOME) { layer = Layer.HOME }

    val wallpaper by produceState<ImageBitmap?>(null, settings.wallpaperStamp) {
        value = if (settings.wallpaperStamp == 0L) {
            null
        } else {
            withContext(Dispatchers.IO) {
                BitmapFactory.decodeFile(settingsVm.wallpaperFile().path)?.asImageBitmap()
            }
        }
    }

    val launchApp: (AppEntry) -> Unit = { app ->
        if (!appsVm.launch(app)) {
            Toast.makeText(context, R.string.app_unavailable, Toast.LENGTH_SHORT).show()
        }
    }
    fun addToRing(app: AppEntry) {
        if (app.key in ringKeys) return
        if (ringKeys.size >= MAX_RING_SIZE) {
            Toast.makeText(context, R.string.ring_full, Toast.LENGTH_SHORT).show()
        } else {
            settingsVm.saveFavorites(ringKeys + app.key)
        }
    }
    fun removeFromRing(app: AppEntry) = settingsVm.saveFavorites(ringKeys - app.key)
    fun moveInRing(app: AppEntry, delta: Int) {
        val i = ringKeys.indexOf(app.key)
        if (i < 0 || ringKeys.size < 2) return
        val j = (i + delta + ringKeys.size) % ringKeys.size
        val list = ringKeys.toMutableList()
        list[i] = list[j].also { list[j] = list[i] }
        settingsVm.saveFavorites(list)
    }
    fun openAccessSettings() {
        val opened = runCatching {
            context.startActivity(
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }.isSuccess
        if (!opened) Toast.makeText(context, R.string.app_unavailable, Toast.LENGTH_SHORT).show()
    }

    Box(modifier.fillMaxSize().background(c.background)) {
        wallpaper?.let { bitmap ->
            Image(bitmap, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(c.background.copy(alpha = settings.wallpaperDim)))
        }

        HomeContent(
            enabled = layer == Layer.HOME,
            settings = settings,
            orbit = orbit,
            ringApps = ringApps,
            showRingHint = appsReady && ringApps.isEmpty(),
            notifItems = notifItems,
            access = access,
            media = media,
            appsVm = appsVm,
            onSwipeUp = { layer = Layer.DRAWER },
            onOpenSettings = { layer = Layer.SETTINGS },
            onLaunch = launchApp,
            onRingLongPress = { menuApp = it },
            onRequestAccess = { showAccessDialog = true },
            onPrevious = mediaRepo::previous,
            onPlayPause = mediaRepo::playPause,
            onNext = mediaRepo::next,
        )

        AnimatedVisibility(
            visible = layer == Layer.DRAWER,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
        ) {
            AppDrawerScreen(
                vm = appsVm,
                iconStyle = settings.iconStyle,
                layout = settings.drawerLayout,
                ringKeys = ringKeys,
                onToggleLayout = {
                    val next = if (settings.drawerLayout == DrawerLayout.GRID) DrawerLayout.LIST else DrawerLayout.GRID
                    settingsVm.set(Keys.DRAWER_LAYOUT, next.name)
                },
                onOpenSettings = { layer = Layer.SETTINGS },
                onClose = { layer = Layer.HOME },
                onLaunch = launchApp,
                onLongPress = { menuApp = it },
                onTogglePin = { app -> if (app.key in ringKeys) removeFromRing(app) else addToRing(app) },
            )
        }

        AnimatedVisibility(
            visible = layer == Layer.SETTINGS,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
        ) {
            SettingsScreen(
                settings = settings,
                vm = settingsVm,
                accessGranted = access,
                reducedMotion = reduced,
                onRequestAccess = { showAccessDialog = true },
                onClose = { layer = Layer.HOME },
            )
        }
    }

    menuApp?.let { app ->
        AppActionsDialog(
            app = app,
            inRing = app.key in ringKeys,
            onDismiss = { menuApp = null },
            onOpen = { launchApp(app) },
            onAdd = { addToRing(app) },
            onRemove = { removeFromRing(app) },
            onMoveBack = { moveInRing(app, -1) },
            onMoveForward = { moveInRing(app, 1) },
        )
    }
    if (showAccessDialog) {
        NotificationAccessDialog(
            onDismiss = { showAccessDialog = false },
            onOpenSettings = {
                showAccessDialog = false
                openAccessSettings()
            },
        )
    }
}

@Composable
private fun HomeContent(
    enabled: Boolean,
    settings: LauncherSettings,
    orbit: OrbitConfig,
    ringApps: List<AppEntry>,
    showRingHint: Boolean,
    notifItems: List<Pair<AppEntry, Int>>,
    access: Boolean,
    media: MediaUi?,
    appsVm: AppsViewModel,
    onSwipeUp: () -> Unit,
    onOpenSettings: () -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onRingLongPress: (AppEntry) -> Unit,
    onRequestAccess: () -> Unit,
    onPrevious: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
) {
    val c = Hudson.colors
    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing) // system bars + display cutouts
            .padding(horizontal = 20.dp, vertical = 12.dp)
            // Swipe up anywhere outside the ring to open the app list.
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                var total = 0f
                val threshold = 96.dp.toPx()
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onVerticalDrag = { _, dy ->
                        total += dy
                        if (total < -threshold) {
                            total = 0f
                            onSwipeUp()
                        }
                    },
                )
            }
            // Press and hold on empty space to open Settings.
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectTapGestures(onLongPress = { onOpenSettings() })
            },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        ClockWidget(settings.clockFormat, settings.clockSize, settings.showDate)

        if (settings.showNotifications) {
            NotificationIndicators(
                accessGranted = access,
                items = notifItems,
                vm = appsVm,
                iconStyle = settings.iconStyle,
                onOpen = onLaunch,
                onRequestAccess = onRequestAccess,
                modifier = Modifier.padding(top = 10.dp),
            )
        }

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            InfiniteRing(
                apps = ringApps,
                vm = appsVm,
                active = enabled,
                onLaunch = onLaunch,
                onLongPress = onRingLongPress,
                modifier = Modifier.fillMaxSize(),
                config = orbit,
            )
            if (showRingHint) {
                Text(
                    text = stringResource(R.string.ring_empty),
                    color = c.dim,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.widthIn(max = 200.dp),
                )
            }
        }

        if (settings.showMedia && media != null) {
            MediaPlayerBanner(media, onPrevious, onPlayPause, onNext)
        }

        Box(
            Modifier.fillMaxWidth().height(44.dp).clickable(onClick = onSwipeUp),
            contentAlignment = Alignment.Center,
        ) {
            Glyph(GlyphKind.ChevronUp, c.dim, Modifier.size(26.dp))
        }
    }
}
