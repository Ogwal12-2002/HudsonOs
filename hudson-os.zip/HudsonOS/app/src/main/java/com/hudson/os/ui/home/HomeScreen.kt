package com.hudson.os.ui.home

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hudson.os.R
import com.hudson.os.data.apps.AppEntry
import com.hudson.os.ui.apps.AppsScreen
import com.hudson.os.ui.apps.AppsViewModel
import com.hudson.os.ui.theme.HudsonColors

@Composable
fun HomeScreen(
    homeSignal: Int,
    modifier: Modifier = Modifier,
    vm: AppsViewModel = viewModel(),
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var showApps by rememberSaveable { mutableStateOf(false) }

    // Reload the app list each time the launcher becomes visible.
    LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) { vm.refresh() }
    }
    // Pressing Home while the app list is open returns to the home screen.
    LaunchedEffect(homeSignal) { if (homeSignal > 0) showApps = false }
    BackHandler(enabled = showApps) { showApps = false }

    val launchApp: (AppEntry) -> Unit = { entry ->
        if (!vm.launch(entry)) {
            Toast.makeText(context, R.string.app_unavailable, Toast.LENGTH_SHORT).show()
        }
    }

    Box(modifier.fillMaxSize().background(HudsonColors.Background)) {
        HomeContent(enabled = !showApps, onSwipeUp = { showApps = true })
        AnimatedVisibility(
            visible = showApps,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
        ) {
            AppsScreen(vm = vm, onLaunch = launchApp)
        }
    }
}

@Composable
private fun HomeContent(enabled: Boolean, onSwipeUp: () -> Unit) {
    val clock = rememberClockState()
    val clockSize = (LocalConfiguration.current.screenWidthDp * 0.19f).coerceIn(52f, 88f).sp

    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing) // system bars + display cutouts
            .padding(horizontal = 24.dp, vertical = 16.dp)
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                var total = 0f
                val threshold = 96.dp.toPx()
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onVerticalDrag = { _, dy ->
                        total += dy
                        if (total < -threshold) {
                            total = 0f
                            onSwipeUp()
                        }
                    },
                )
            },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = clock.time,
            color = HudsonColors.Foreground,
            fontSize = clockSize,
            fontWeight = FontWeight.ExtraLight,
            letterSpacing = 1.sp,
        )
        Text(
            text = clock.date,
            color = HudsonColors.Dim,
            fontSize = 14.sp,
            letterSpacing = 1.5.sp,
            modifier = Modifier.padding(top = 8.dp),
        )

        // Outline only. The interactive Infinite Ring replaces this in Stage 3.
        Box(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val radius = size.minDimension * 0.42f
                drawCircle(
                    color = HudsonColors.Outline,
                    radius = radius,
                    style = Stroke(width = 1.dp.toPx()),
                )
                drawCircle(
                    color = HudsonColors.OutlineDim,
                    radius = radius * 0.52f,
                    style = Stroke(
                        width = 1.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(
                            floatArrayOf(3.dp.toPx(), 9.dp.toPx()),
                        ),
                    ),
                )
            }
            Text(
                text = stringResource(R.string.tagline),
                color = HudsonColors.Dim,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.widthIn(max = 150.dp),
            )
        }
    }
}
