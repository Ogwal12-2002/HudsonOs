package com.hudson.os.ui.home

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hudson.os.R
import com.hudson.os.data.apps.AppEntry
import com.hudson.os.ui.apps.AppActionsDialog
import com.hudson.os.ui.apps.AppsScreen
import com.hudson.os.ui.apps.AppsUiState
import com.hudson.os.ui.apps.AppsViewModel
import com.hudson.os.ui.ring.InfiniteRing
import com.hudson.os.ui.ring.RingConfig
import com.hudson.os.ui.ring.systemReducedMotion
import com.hudson.os.ui.theme.HudsonColors

private const val DEFAULT_RING_SIZE = 8

@Composable
fun HomeScreen(
    homeSignal: Int,
    modifier: Modifier = Modifier,
    vm: AppsViewModel = viewModel(),
    ringVm: RingViewModel = viewModel(),
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var showApps by rememberSaveable { mutableStateOf(false) }
    var menuApp by remember { mutableStateOf<AppEntry?>(null) }

    val appsState by vm.state.collectAsStateWithLifecycle()
    val saved by ringVm.saved.collectAsStateWithLifecycle()
    val allApps = (appsState as? AppsUiState.Ready)?.apps.orEmpty()
    val ringReady = saved != null && appsState is AppsUiState.Ready
    val ringApps = remember(saved, allApps) {
        val keys = saved?.let { it.keys ?: allApps.take(DEFAULT_RING_SIZE).map { app -> app.key } }.orEmpty()
        val byKey = allApps.associateBy { it.key }
        keys.mapNotNull { byKey[it] }
    }
    val ringKeys = ringApps.map { it.key }
    val config = remember { RingConfig(reducedMotion = systemReducedMotion(context)) }

    // Reload the app list each time the launcher becomes visible.
    LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) { vm.refresh() }
    }
    // Pressing Home while the app list is open returns to the home screen.
    LaunchedEffect(homeSignal) { if (homeSignal > 0) showApps = false }
    BackHandler(enabled = showApps) { showApps = false }

    val launchApp: (AppEntry) -> Unit = { entry ->
        if (!vm.launch(entry)) {
            Toast.makeText(context, R.string.app_unavailable, Toast.LENGTH_SHORT).show()
        }
    }
    fun move(app: AppEntry, delta: Int) {
        val i = ringKeys.indexOf(app.key)
        if (i < 0 || ringKeys.size < 2) return
        val j = (i + delta + ringKeys.size) % ringKeys.size
        val list = ringKeys.toMutableList()
        list[i] = list[j].also { list[j] = list[i] }
        ringVm.save(list)
    }

    Box(modifier.fillMaxSize().background(HudsonColors.Background)) {
        HomeContent(
            enabled = !showApps,
            onSwipeUp = { showApps = true },
            ringApps = ringApps,
            ringReady = ringReady,
            vm = vm,
            config = config,
            onLaunch = launchApp,
            onRingLongPress = { menuApp = it },
        )
        AnimatedVisibility(
            visible = showApps,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
        ) {
            AppsScreen(vm = vm, onLaunch = launchApp, onLongPress = { menuApp = it })
        }
    }

    menuApp?.let { app ->
        AppActionsDialog(
            app = app,
            inRing = app.key in ringKeys,
            onDismiss = { menuApp = null },
            onOpen = { launchApp(app) },
            onAdd = { ringVm.save(ringKeys + app.key) },
            onRemove = { ringVm.save(ringKeys - app.key) },
            onMoveBack = { move(app, -1) },
            onMoveForward = { move(app, 1) },
        )
    }
}

@Composable
private fun HomeContent(
    enabled: Boolean,
    onSwipeUp: () -> Unit,
    ringApps: List<AppEntry>,
    ringReady: Boolean,
    vm: AppsViewModel,
    config: RingConfig,
    onLaunch: (AppEntry) -> Unit,
    onRingLongPress: (AppEntry) -> Unit,
) {
    val clock = rememberClockState()
    val clockSize = (LocalConfiguration.current.screenWidthDp * 0.19f).coerceIn(52f, 88f).sp

    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing) // system bars + display cutouts
            .padding(horizontal = 24.dp, vertical = 16.dp)
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                var total = 0f
                val threshold = 96.dp.toPx()
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onVerticalDrag = { _, dy ->
                        total += dy
                        if (total < -threshold) {
                            total = 0f
                            onSwipeUp()
                        }
                    },
                )
            },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = clock.time,
            color = HudsonColors.Foreground,
            fontSize = clockSize,
            fontWeight = FontWeight.ExtraLight,
            letterSpacing = 1.sp,
        )
        Text(
            text = clock.date,
            color = HudsonColors.Dim,
            fontSize = 14.sp,
            letterSpacing = 1.5.sp,
            modifier = Modifier.padding(top = 8.dp),
        )

        Box(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentAlignment = Alignment.Center,
        ) {
            InfiniteRing(
                apps = ringApps,
                vm = vm,
                active = enabled,
                onLaunch = onLaunch,
                onLongPress = onRingLongPress,
                modifier = Modifier.fillMaxSize(),
                config = config,
            )
            if (ringReady && ringApps.isEmpty()) {
                Text(
                    text = stringResource(R.string.ring_empty),
                    color = HudsonColors.Dim,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.widthIn(max = 200.dp),
                )
            }
        }
    }
}
