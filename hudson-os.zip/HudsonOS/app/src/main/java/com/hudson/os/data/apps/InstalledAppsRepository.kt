package com.hudson.os.data.apps

import android.content.Context
import android.content.pm.LauncherApps
import android.graphics.AdaptiveIconDrawable
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Process
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import com.hudson.os.data.IconStyle
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** [tint] true means the bitmap is a mask to be coloured with the theme foreground. */
class AppIcon(val bitmap: ImageBitmap, val tint: Boolean)

/**
 * Uses the LauncherApps API, the supported way for a home app to list and start apps.
 * It follows Android package-visibility rules without QUERY_ALL_PACKAGES.
 */
class InstalledAppsRepository(context: Context) {
    private val appContext = context.applicationContext
    private val launcherApps = appContext.getSystemService(LauncherApps::class.java)
    private val iconCache = ConcurrentHashMap<String, AppIcon>()

    suspend fun load(): List<AppEntry> = withContext(Dispatchers.IO) {
        val user = Process.myUserHandle()
        launcherApps.getActivityList(null, user)
            .filter { it.componentName.packageName != appContext.packageName }
            .map { AppEntry(it.componentName, it.label.toString(), user) }
            .sortedBy { it.label.lowercase() }
    }

    /** Null means "no usable icon for this style"; the UI then shows a consistent fallback. */
    suspend fun icon(entry: AppEntry, sizePx: Int, style: IconStyle): AppIcon? {
        val cacheKey = "${entry.key}@$sizePx/${style.name}"
        iconCache[cacheKey]?.let { return it }
        return withContext(Dispatchers.IO) {
            runCatching { render(entry, sizePx, style) }.getOrNull()?.also { iconCache[cacheKey] = it }
        }
    }

    private fun render(entry: AppEntry, sizePx: Int, style: IconStyle): AppIcon? {
        val info = launcherApps.getActivityList(entry.component.packageName, entry.user)
            .firstOrNull { it.componentName == entry.component } ?: return null
        val drawable = info.getBadgedIcon(0)
        return when (style) {
            IconStyle.ORIGINAL -> AppIcon(drawable.toBitmap(sizePx, sizePx).asImageBitmap(), false)
            IconStyle.MONOCHROME -> AppIcon(grayscale(drawable.toBitmap(sizePx, sizePx)).asImageBitmap(), false)
            IconStyle.OUTLINE -> monochromeLayer(drawable, sizePx)?.let { AppIcon(it.asImageBitmap(), true) }
        }
    }

    /** Android 13+ themed icons: apps that ship a monochrome layer give a clean one-colour glyph. */
    private fun monochromeLayer(drawable: Drawable, sizePx: Int): Bitmap? {
        if (Build.VERSION.SDK_INT < 33) return null
        val mono = (drawable as? AdaptiveIconDrawable)?.monochrome ?: return null
        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        // Adaptive layers are 108dp with a 72dp visible window, so crop the outer quarter away.
        val inset = (sizePx * 0.25f).toInt()
        mono.setBounds(-inset, -inset, sizePx + inset, sizePx + inset)
        mono.draw(Canvas(bitmap))
        return bitmap
    }

    private fun grayscale(source: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val paint = Paint().apply {
            colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
        }
        Canvas(out).drawBitmap(source, 0f, 0f, paint)
        return out
    }

    /** Returns false when the app was removed, disabled or cannot be started. */
    fun launch(entry: AppEntry): Boolean = runCatching {
        launcherApps.startMainActivity(entry.component, entry.user, null, null)
    }.isSuccess
}
