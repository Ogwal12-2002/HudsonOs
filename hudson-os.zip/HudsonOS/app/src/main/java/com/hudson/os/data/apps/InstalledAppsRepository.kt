package com.hudson.os.data.apps

import android.content.Context
import android.content.pm.LauncherApps
import android.os.Process
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Uses the LauncherApps API, the supported way for a home app to list and start apps.
 * It follows Android package-visibility rules without QUERY_ALL_PACKAGES.
 */
class InstalledAppsRepository(context: Context) {
    private val appContext = context.applicationContext
    private val launcherApps = appContext.getSystemService(LauncherApps::class.java)
    private val iconCache = ConcurrentHashMap<String, ImageBitmap>()

    suspend fun load(): List<AppEntry> = withContext(Dispatchers.IO) {
        val user = Process.myUserHandle()
        launcherApps.getActivityList(null, user)
            .filter { it.componentName.packageName != appContext.packageName }
            .map { AppEntry(it.componentName, it.label.toString(), user) }
            .sortedBy { it.label.lowercase() }
    }

    suspend fun icon(entry: AppEntry, sizePx: Int): ImageBitmap? {
        val cacheKey = "${entry.key}@$sizePx"
        iconCache[cacheKey]?.let { return it }
        return withContext(Dispatchers.IO) {
            runCatching {
                launcherApps.getActivityList(entry.component.packageName, entry.user)
                    .firstOrNull { it.componentName == entry.component }
                    ?.getBadgedIcon(0)
                    ?.toBitmap(sizePx, sizePx)
                    ?.asImageBitmap()
            }.getOrNull()?.also { iconCache[cacheKey] = it }
        }
    }

    /** Returns false when the app was removed, disabled or cannot be started. */
    fun launch(entry: AppEntry): Boolean = runCatching {
        launcherApps.startMainActivity(entry.component, entry.user, null, null)
    }.isSuccess
}
