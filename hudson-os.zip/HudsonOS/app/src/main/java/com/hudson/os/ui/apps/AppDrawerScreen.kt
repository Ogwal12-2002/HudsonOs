package com.hudson.os.ui.apps

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.hudson.os.R
import com.hudson.os.data.DrawerLayout
import com.hudson.os.data.IconStyle
import com.hudson.os.data.apps.AppEntry
import com.hudson.os.ui.theme.Glyph
import com.hudson.os.ui.theme.GlyphButton
import com.hudson.os.ui.theme.GlyphKind
import com.hudson.os.ui.theme.Hudson

/** Swipe-up app list: search, grid or list layout, launching, and adding apps to the ring. */
@Composable
fun AppDrawerScreen(
    vm: AppsViewModel,
    iconStyle: IconStyle,
    layout: DrawerLayout,
    ringKeys: List<String>,
    onToggleLayout: () -> Unit,
    onOpenSettings: () -> Unit,
    onClose: () -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
    onTogglePin: (AppEntry) -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = Hudson.colors
    val state by vm.state.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }

    Column(
        modifier
            .fillMaxSize()
            .background(c.background.copy(alpha = 0.97f))
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SearchField(query, { query = it }, Modifier.weight(1f))
            GlyphButton(
                if (layout == DrawerLayout.GRID) GlyphKind.List else GlyphKind.Grid,
                stringResource(R.string.cd_toggle_layout),
                onToggleLayout,
            )
            GlyphButton(GlyphKind.Gear, stringResource(R.string.cd_settings), onOpenSettings)
            GlyphButton(GlyphKind.Close, stringResource(R.string.cd_close), onClose)
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(top = 12.dp), contentAlignment = Alignment.Center) {
            when (val s = state) {
                is AppsUiState.Loading -> CircularProgressIndicator(
                    color = c.foreground,
                    strokeWidth = 1.dp,
                    modifier = Modifier.size(32.dp),
                )
                is AppsUiState.Error -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(stringResource(R.string.apps_error), color = c.dim)
                    TextButton(onClick = vm::refresh) {
                        Text(stringResource(R.string.apps_retry), color = c.foreground)
                    }
                }
                is AppsUiState.Ready -> {
                    val shown = remember(s.apps, query) { filterApps(s.apps, query) }
                    when {
                        s.apps.isEmpty() -> Text(stringResource(R.string.apps_empty), color = c.dim)
                        shown.isEmpty() -> Text(stringResource(R.string.no_match), color = c.dim)
                        layout == DrawerLayout.GRID -> AppGrid(shown, vm, iconStyle, onLaunch, onLongPress)
                        else -> AppList(shown, vm, iconStyle, ringKeys, onLaunch, onLongPress, onTogglePin)
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit, modifier: Modifier) {
    val c = Hudson.colors
    BasicTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        textStyle = TextStyle(color = c.foreground, fontSize = 16.sp),
        cursorBrush = SolidColor(c.accent),
        modifier = modifier,
        decorationBox = { inner ->
            Row(
                Modifier.height(40.dp).border(1.dp, c.outline, CircleShape).padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Glyph(GlyphKind.Search, c.dim, Modifier.size(16.dp))
                Box(Modifier.weight(1f)) {
                    if (value.isEmpty()) Text(stringResource(R.string.search_hint), color = c.dim, fontSize = 16.sp)
                    inner()
                }
            }
        },
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppGrid(
    apps: List<AppEntry>,
    vm: AppsViewModel,
    iconStyle: IconStyle,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
) {
    val c = Hudson.colors
    LazyVerticalGrid(
        columns = GridCells.Adaptive(76.dp),
        contentPadding = PaddingValues(4.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        items(apps, key = { it.key }) { app ->
            Column(
                modifier = Modifier
                    .combinedClickable(onClick = { onLaunch(app) }, onLongClick = { onLongPress(app) })
                    .padding(4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                IconFrame(vm, app, iconStyle, 52.dp)
                Text(
                    text = app.label,
                    color = c.foreground,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppList(
    apps: List<AppEntry>,
    vm: AppsViewModel,
    iconStyle: IconStyle,
    ringKeys: List<String>,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
    onTogglePin: (AppEntry) -> Unit,
) {
    val c = Hudson.colors
    LazyColumn(Modifier.fillMaxSize()) {
        items(apps, key = { it.key }) { app ->
            val pinned = app.key in ringKeys
            Row(
                Modifier
                    .fillMaxWidth()
                    .combinedClickable(onClick = { onLaunch(app) }, onLongClick = { onLongPress(app) })
                    .padding(vertical = 8.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                IconFrame(vm, app, iconStyle, 44.dp)
                Text(app.label, color = c.foreground, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Box(
                    Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(if (pinned) c.accent else Color.Transparent)
                        .border(1.dp, if (pinned) c.accent else c.outline, CircleShape)
                        .clickable { onTogglePin(app) },
                    contentAlignment = Alignment.Center,
                ) {
                    Glyph(
                        if (pinned) GlyphKind.Check else GlyphKind.Plus,
                        if (pinned) c.background else c.foreground,
                        Modifier.size(16.dp),
                    )
                }
            }
        }
    }
}

/** Circular frame around an icon, matching the ring's look. */
@Composable
private fun IconFrame(vm: AppsViewModel, app: AppEntry, style: IconStyle, size: androidx.compose.ui.unit.Dp) {
    val c = Hudson.colors
    Box(
        Modifier
            .size(size)
            .then(if (style == IconStyle.ORIGINAL) Modifier else Modifier.border(1.dp, c.outline, CircleShape)),
        contentAlignment = Alignment.Center,
    ) {
        AppIconImage(vm, app, style, size)
    }
}
