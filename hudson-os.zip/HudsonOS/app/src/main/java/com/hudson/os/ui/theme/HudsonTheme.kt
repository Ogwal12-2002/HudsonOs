package com.hudson.os.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Void theme (default). The other four themes arrive in Stage 5. */
object HudsonColors {
    val Background = Color(0xFF000000)
    val Foreground = Color(0xFFFFFFFF)
    val Dim = Color(0xFF8D8D8D)
    val Outline = Color(0x5CFFFFFF)
    val OutlineDim = Color(0x33FFFFFF)
}

private val VoidScheme = darkColorScheme(
    background = HudsonColors.Background,
    surface = HudsonColors.Background,
    onBackground = HudsonColors.Foreground,
    onSurface = HudsonColors.Foreground,
    primary = HudsonColors.Foreground,
)

@Composable
fun HudsonTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = VoidScheme, content = content)
}
