package com.hudson.os.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.hudson.os.data.ThemeId

@Immutable
data class HudsonPalette(
    val background: Color,
    val foreground: Color,
    val dim: Color,
    /** Used for thin lines and the selection highlight. */
    val accent: Color,
    val isLight: Boolean,
) {
    val outline: Color get() = accent.copy(alpha = 0.40f)
    val outlineDim: Color get() = accent.copy(alpha = 0.20f)
}

fun paletteOf(id: ThemeId): HudsonPalette = when (id) {
    ThemeId.VOID -> HudsonPalette(Color(0xFF000000), Color(0xFFFFFFFF), Color(0xFF8D8D8D), Color(0xFFFFFFFF), false)
    ThemeId.GHOST -> HudsonPalette(Color(0xFF1C1D1F), Color(0xFFE8E8E8), Color(0xFF8F9196), Color(0xFFC4C8CF), false)
    ThemeId.ICE -> HudsonPalette(Color(0xFF06122A), Color(0xFFE0F2FF), Color(0xFF6D8DB2), Color(0xFF7FD4FF), false)
    ThemeId.NEON -> HudsonPalette(Color(0xFF07060E), Color(0xFFF1F1FF), Color(0xFF7A7994), Color(0xFF39FF9C), false)
    ThemeId.PAPER -> HudsonPalette(Color(0xFFF3F0E8), Color(0xFF141414), Color(0xFF6A6A6A), Color(0xFF141414), true)
}

val LocalPalette = staticCompositionLocalOf { paletteOf(ThemeId.VOID) }

object Hudson {
    val colors: HudsonPalette
        @Composable
        @ReadOnlyComposable
        get() = LocalPalette.current
}

@Composable
fun HudsonTheme(themeId: ThemeId, content: @Composable () -> Unit) {
    val palette = remember(themeId) { paletteOf(themeId) }
    val scheme = if (palette.isLight) {
        lightColorScheme(
            background = palette.background,
            surface = palette.background,
            onBackground = palette.foreground,
            onSurface = palette.foreground,
            primary = palette.foreground,
        )
    } else {
        darkColorScheme(
            background = palette.background,
            surface = palette.background,
            onBackground = palette.foreground,
            onSurface = palette.foreground,
            primary = palette.foreground,
        )
    }
    CompositionLocalProvider(LocalPalette provides palette) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
