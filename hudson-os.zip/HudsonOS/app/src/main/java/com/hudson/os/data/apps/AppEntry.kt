package com.hudson.os.data.apps

import android.content.ComponentName
import android.os.UserHandle
import androidx.compose.runtime.Immutable

/** One launchable activity. Icons are loaded lazily, never stored here. */
@Immutable
data class AppEntry(
    val component: ComponentName,
    val label: String,
    val user: UserHandle,
) {
    val key: String get() = component.flattenToString()
}
