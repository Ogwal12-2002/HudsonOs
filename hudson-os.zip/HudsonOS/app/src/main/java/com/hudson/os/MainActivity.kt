package com.hudson.os

import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hudson.os.data.AppLanguage
import com.hudson.os.settings.SettingsViewModel
import com.hudson.os.ui.home.HomeScreen
import com.hudson.os.ui.theme.HudsonTheme
import com.hudson.os.ui.theme.paletteOf
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var homeSignal by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)
        setContent {
            val settingsVm: SettingsViewModel = viewModel()
            val loaded by settingsVm.settings.collectAsStateWithLifecycle()
            val settings = loaded
            if (settings == null) {
                // Settings are read once at start so the wrong theme or language never flashes.
                Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black))
            } else {
                LocalizedContent(settings.language) {
                    HudsonTheme(settings.theme) {
                        val light = paletteOf(settings.theme).isLight
                        LaunchedEffect(light) {
                            WindowCompat.getInsetsController(window, window.decorView).apply {
                                isAppearanceLightStatusBars = light
                                isAppearanceLightNavigationBars = light
                            }
                        }
                        // A launcher is the bottom of the stack: Back must not close it.
                        BackHandler(enabled = true) {}
                        HomeScreen(homeSignal = homeSignal, settings = settings, settingsVm = settingsVm)
                    }
                }
            }
        }
    }

    // singleTask: pressing Home while we are already on top arrives here.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) homeSignal++
    }
}

/** Applies the in-app language to every string and date, without restarting the activity. */
@Composable
private fun LocalizedContent(language: AppLanguage, content: @Composable () -> Unit) {
    val baseContext = LocalContext.current
    val baseConfig = LocalConfiguration.current
    val localized = remember(language, baseContext, baseConfig) {
        if (language == AppLanguage.SYSTEM) {
            baseContext to baseConfig
        } else {
            val tag = if (language == AppLanguage.FR) "fr" else "en"
            val config = Configuration(baseConfig).apply { setLocale(Locale.forLanguageTag(tag)) }
            baseContext.createConfigurationContext(config) to config
        }
    }
    CompositionLocalProvider(
        LocalContext provides localized.first,
        LocalConfiguration provides localized.second,
        content = content,
    )
}
