package com.hudson.os.ui.home

import android.text.format.DateFormat
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import com.hudson.os.data.ClockFormat
import com.hudson.os.data.ClockSize
import com.hudson.os.ui.theme.Hudson
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.delay

@Immutable
data class ClockUiState(val time: String, val date: String)

/**
 * Ticks once per minute, and only while the launcher is visible (STARTED).
 * No per-second wake-ups, so it costs almost no battery.
 */
@Composable
fun rememberClockState(format: ClockFormat): ClockUiState {
    val context = LocalContext.current
    val locale = LocalConfiguration.current.locales[0]
    val lifecycleOwner = LocalLifecycleOwner.current
    var now by remember { mutableStateOf(LocalDateTime.now()) }

    LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) {
                now = LocalDateTime.now()
                delay(60_000L - System.currentTimeMillis() % 60_000L)
            }
        }
    }

    val is24 = when (format) {
        ClockFormat.SYSTEM -> DateFormat.is24HourFormat(context)
        ClockFormat.H24 -> true
        ClockFormat.H12 -> false
    }
    val timeFormat = remember(is24, locale) {
        DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm", locale)
    }
    val dateFormat = remember(locale) { DateTimeFormatter.ofPattern("EEEE d MMMM", locale) }
    return ClockUiState(now.format(timeFormat), now.format(dateFormat).uppercase(locale))
}

@Composable
fun ClockWidget(
    format: ClockFormat,
    size: ClockSize,
    showDate: Boolean,
    modifier: Modifier = Modifier,
) {
    val c = Hudson.colors
    val clock = rememberClockState(format)
    val base = (LocalConfiguration.current.screenWidthDp * 0.24f).coerceIn(56f, 100f)
    val scale = when (size) {
        ClockSize.SMALL -> 0.75f
        ClockSize.MEDIUM -> 1f
        ClockSize.LARGE -> 1.2f
    }
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = clock.time,
            color = c.foreground,
            fontSize = (base * scale).sp,
            fontWeight = FontWeight.Light,
            letterSpacing = 1.sp,
        )
        if (showDate) {
            Text(
                text = clock.date,
                color = c.dim,
                fontSize = 15.sp,
                letterSpacing = 3.sp,
                modifier = Modifier.padding(top = 6.dp),
            )
        }
    }
}
